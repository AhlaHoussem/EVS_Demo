package solutions.exercise1;

import org.junit.Before;
import org.junit.Test;
import org.sopra.api.exercises.ExerciseSubmission;
import org.sopra.api.exercises.exercise1.AbstractPairFinderTest;
import org.sopra.api.exercises.exercise1.PairFinder;

public class PairFinderTest extends AbstractPairFinderTest implements ExerciseSubmission {

	//TODO: public PairFinder sut = new PairFinderImpl();
	public PairFinder sut;
	
	@Before
	public void setup() {
		sut = new PairFinderImpl();
	}

	@Test
	public void testFindConsumerProducerPairs() {
		sut.findConsumerProducerPairs(graph1);
	}

	@Override
    public String getTeamIdentifier() {
		return "Musterloesung";
    }
	
}