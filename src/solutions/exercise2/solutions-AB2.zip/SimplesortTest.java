package solutions.exercise2;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.instanceOf;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;

import org.junit.Test;
import org.sopra.api.exercises.ExerciseSubmission;
import org.sopra.api.exercises.exercise2.AbstractSimplesortTest;

public class SimplesortTest extends AbstractSimplesortTest implements ExerciseSubmission {
	
    @Override
    @Test
    public void testSimplesort() {
    	testSimplesort(new Integer[] { -1, -3 }, new Integer[] { -3, -1 });
    	testSimplesort(new Integer[] { 3, 4, 2, 4, 0, 10, 1, 0 }, new Integer[] { 0, 0, 1, 2, 3, 4, 4, 10 });
    	testSimplesort(new Integer[] { 1, 1, 1, 1, 0, 1, 1, -3 }, new Integer[] { -3, 0, 1, 1, 1, 1, 1, 1 });
    	testSimplesort(new Integer[] { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0 }, new Integer[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 });
    }

    private void testSimplesort(Integer[] input, Integer[] expected) {
    	sut.simplesort(input, 0, input.length - 1);
    	assertThat("Array is not sorted.", input, equalTo(expected));
    }

    @Override
    @Test
    public void testSimplesort_Parameters() {
		try {
			sut.simplesort(null, 1, 3);
			fail("IllegalArgumentException was not detected.");
		} catch (Exception e) {
			assertThat("Expected IllegalArgumentException.", e, instanceOf(IllegalArgumentException.class));
		}

		try {
			sut.simplesort(new Integer[] { 1, 2, 3 }, -1, 2);
			fail("IllegalArgumentException was not detected.");
		} catch (Exception e) {
			assertThat("Expected IllegalArgumentException.", e, instanceOf(IllegalArgumentException.class));
		}

		try {
			sut.simplesort(new Integer[] { 1, 2, 3 }, 4, 5);
			fail("IllegalArgumentException was not detected.");
		} catch (Exception e) {
			assertThat("Expected IllegalArgumentException.", e, instanceOf(IllegalArgumentException.class));
		}

    }

    @Override
    public String getTeamIdentifier() {
    	return "Musterloesung";
    }
	
}
