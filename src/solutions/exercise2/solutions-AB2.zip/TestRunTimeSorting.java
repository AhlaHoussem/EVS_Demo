package solutions.exercise2;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.sopra.api.exercises.ExerciseSubmission;
import org.sopra.api.exercises.exercise2.AbstractTestRunTimeSorting;
import org.sopra.api.exercises.exercise2.Quicksort;
import org.sopra.api.exercises.exercise2.Simplesort;

import com.google.common.base.Stopwatch;

public class TestRunTimeSorting extends AbstractTestRunTimeSorting implements ExerciseSubmission {
	
	private static Quicksort<Integer> quickSorter;
	private static Simplesort<Integer> simpleSorter;
	private Stopwatch stopwatch;
	private Integer[] ordered, shuffled;
	private int listLength = 5000;
	
	@BeforeClass
	public static void initialize() {
		quickSorter = new QuicksortImpl<>(comparator); 
		simpleSorter = new SimplesortImpl<>(comparator); 
	}
	
	@Before
	@Override
	public void setup() {
		shuffled = createShuffledIntArray(listLength);
		ordered = createOrderedIntArray(listLength);		
		
		stopwatch = Stopwatch.createUnstarted();
	}

	@Test
	@Override
	public void quicksortRunTimeTest() {
				
		stopwatch.start();
		quickSorter.quicksort(shuffled,0,shuffled.length-1);
		stopwatch.stop();
		long timeElapsed = stopwatch.elapsed(TimeUnit.MICROSECONDS);
		System.out.println("Time elapsed for sorting shuffled array with QuickSort = " + timeElapsed + " µs.");
		
		assertArrayEquals("Not correct sorting, QuickSort", shuffled, ordered);
	}
	
	@Test
	@Override
	public void simplesortRunTimeTest() {
		
		stopwatch.start();
		simpleSorter.simplesort(shuffled,0,shuffled.length-1);
		stopwatch.stop();
		long timeElapsed = stopwatch.elapsed(TimeUnit.MICROSECONDS);
		System.out.println("Time elapsed for sorting shuffled array with SimpleSort = " + timeElapsed + " µs.");

		assertArrayEquals("Not correct sorting, SimpleSort", shuffled, ordered);

	}

	@Override
	public String getTeamIdentifier() {
		return "Musterloesung";
	}
	
}
