package solutions.exercise2;

import java.util.Comparator;

import org.sopra.api.exercises.ExerciseSubmission;
import org.sopra.api.exercises.exercise2.Simplesort;

public class SimplesortImpl<T> implements Simplesort<T>, ExerciseSubmission {
	
	Comparator<T> comparator;

	public SimplesortImpl(Comparator<T> comparator) {
		if (comparator == null) {
		    throw new IllegalArgumentException("Comparator can't be null.");
		}
		this.comparator = comparator;
	}

	@Override
	public void simplesort(T[] arr, int left, int right) {
		if (arr == null) {
		    throw new IllegalArgumentException("Array is not allowed to be null.");
		}

		if (left < 0 || right > arr.length - 1 || right < left) {
		    throw new IllegalArgumentException("Invalid interval.");
		}
		
		for ( int i = left ;  i <= right ; i++) {
			for ( int j = i+1; j <= right ; j++) {
				if(comparator.compare(arr[j], arr[i]) < 0) { 
					T tmp = arr[i];
					arr[i] = arr[j];
					arr[j] = tmp;					
				}
			}
		}
	}

	@Override
	public String getTeamIdentifier() {
		return "Musterloesung";
	}
	
}
